#ifndef __THREADS_POOL_H__
#define  __THREADS_POOL_H__





#include "tasks_queue.h"
#include "tasks_implem.h"


// typedef struct threads {
// ;
//   tasks_queue_t* queue ;  // queue
// } threads_pool ;

void threads_init() ;

void consume() ;









#endif
